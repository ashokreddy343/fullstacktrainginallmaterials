﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using JWTAuth.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace JWTAuth.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BlogsController : ControllerBase
    {
        private IEnumerable<Blog> blogs = new List<Blog>
        {
            new Blog{Id=1,Title="Blog 1",Content="Blog Content 1",AddedBy="ashok-1",AddedDate=DateTime.Now},
            new Blog{Id=2,Title="Blog 2",Content="Blog Content 2",AddedBy="ashok-2",AddedDate=DateTime.Now},
            new Blog{Id=3,Title="Blog 3",Content="Blog Content 3",AddedBy="ashok-3",AddedDate=DateTime.Now}
        };

        [HttpGet("",Name ="ListBlogs")]
        [Authorize]
        public ActionResult<IEnumerable<Blog>> GetBlogs()
        {
            return blogs.ToList();
        }
    }
}