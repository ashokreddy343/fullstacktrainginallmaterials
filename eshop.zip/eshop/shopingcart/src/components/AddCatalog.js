import React from "react";
import axios from "axios";

class AddCatalog extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      imageURL: ""
    };
    this.handleUploadImage = this.handleUploadImage.bind(this);
  }

  handleUploadImage(ev) {
    ev.preventDefault();
    const data = new FormData();
    data.append("file", this.uploadInput.files[0]);
    data.append("productName", this.productName.value);
    data.append("price", this.price.value);
    axios
      .post("http://localhost:7001/api/catalog", data)
      .then(function(response) {
        console.log(response);
      })
      .catch(function(error) {
        console.log(error);
      });
  }

  render() {
    return (
      <form onSubmit={this.handleUploadImage}>
        <div>
          <input
            className="fileClass"
            ref={ref => {
              this.uploadInput = ref;
            }}
            type="file"
          />
        </div>
        <div>
          <input
            ref={ref => {
              this.productName = ref;
            }}
            type="text"
            placeholder="Enter Product name"
          />
          <br />
          <br />
          <input
            ref={ref => {
              this.price = ref;
            }}
            type="text"
            placeholder="Enter Product price"
          />
        </div>
        <br />
        <div>
          <button>Upload</button>
        </div>
      </form>
    );
  }
}

export default AddCatalog;
