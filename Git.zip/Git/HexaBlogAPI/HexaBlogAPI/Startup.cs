﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.EntityFrameworkCore;
using HexaBlogAPI.Infrastructure;
using HexaBlogAPI.Models;
using HexaBlogAPI.Repositories;
using Microsoft.AspNetCore.Http;
using HexaBlogAPI.Filters;
using Swashbuckle.AspNetCore.Swagger;
using System.Reflection;
using System.IO;
using Microsoft.AspNetCore.Authentication.JwtBearer;

namespace HexaBlogAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors();
            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                   .AddIdentityServerAuthentication(options =>
                   {
                       options.Authority = Configuration.GetValue<string>("IdentityServerUrl");
                       options.RequireHttpsMetadata = false;
                       options.ApiName = "BlogAPI";
                   });

            services.AddCors(options =>
            {
                //options.AddDefaultPolicy(policy =>
                //{
                //    policy.AllowAnyOrigin()
                //          .AllowAnyMethod()
                //          .AllowAnyHeader();
                //});
                
                options.AddPolicy("MyPolicy", policy =>
                {
                    policy.AllowAnyOrigin()
                          .AllowAnyMethod()
                          .AllowAnyHeader();
                });
            });
            services.AddDbContext<BlogsContext>(options =>
            {
                options.UseSqlServer(Configuration.GetValue<string>("ConnectionString"));
            });
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new Swashbuckle.AspNetCore.Swagger.Info
                {
                    Title="HexaBlog API",
                    Version="v1",
                    Contact=new Contact
                    {
                        Name="Ashok",Email="ashok@gmail.com",Url="https://streamingskills.blog"
                    },
                    Description="Blogs written by Hexaware Bloggers",
                    TermsOfService=string.Empty,
                    License=new License { Name="MIT License",Url= "https://streamingskills.blog"}
                });
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                options.IncludeXmlComments(xmlPath);
            });

            
            

            services.AddScoped<IRepository<Blog>, Repository<Blog>>();
            services.AddMvc(options =>
            {
                options.Filters.Add(typeof(ApiExceptionFilter));
            })
                .SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
            //services.AddMvcCore(options =>
            //{
            //    options.Filters.Add(typeof(ApiExceptionFilter));
            //})
            //    .AddAuthorization()
            //    .AddJsonFormatters()
            //    .SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler(options =>
                {
                    options.Run(async (context) =>
                    {
                        var msg = "Some error occured in the server";
                        await context.Response.WriteAsync(msg);
                    });
                });
            }
            InitializeDatabase(app);
            app.UseStaticFiles();
            app.UseCors();
            app.UseAuthentication();
            app.UseCors("MyPolicy");
            app.UseSwagger();  //swagger documentation
            app.UseSwaggerUI(options => {
                options.SwaggerEndpoint("/swagger/v1/swagger.json", "HexaBlog API");
                options.RoutePrefix = string.Empty;
            });
            //app.UseCors(options =>
            //{
            //    options.AllowAnyOrigin()
            //           .AllowAnyMethod()
            //           .AllowAnyHeader();
            //    //options.WithOrigins("abc.com", "xyz.com")
            //    //        .WithMethods("GET")
            //    //        .WithHeaders("Content-Type", "Content-Length", "Authorization");
            //});
            app.UseMvc();
        }

        private void InitializeDatabase(IApplicationBuilder app)
        {
            using(var serviceScope = app.ApplicationServices.GetService<IServiceScopeFactory>().CreateScope())
            {
                serviceScope.ServiceProvider.GetRequiredService<BlogsContext>().Database.Migrate();
            }
        }
    }
}
