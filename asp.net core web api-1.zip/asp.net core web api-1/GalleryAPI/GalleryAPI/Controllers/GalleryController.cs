﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using GalleryAPI.Models;
using GalleryAPI.Repositories;
using GalleryAPI.ServiceHelpers;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace GalleryAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GalleryController : ControllerBase
    {
        private IRepository<ImageData> repository;
        private IHostingEnvironment _hostingEnvironment;
        private IConfiguration configuration;

        public GalleryController(IRepository<ImageData> repo, IHostingEnvironment hostingEnvironment, IConfiguration configuration)
        {
            this.repository = repo;
            _hostingEnvironment = hostingEnvironment;
            this.configuration = configuration;
        }

        //GET /api/images
        [HttpGet("", Name = "ListImages")]
        public IEnumerable<ImageData> GetImages()
        {
            return this.repository.GetAll();
        }


        [HttpGet("{id:int}", Name = "GetBlog")]
        public async Task<ActionResult<ImageData>> GetBlogById(int id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            var item = await this.repository.GetByIdAsync(id);
            if (item == null)
                return NotFound();
            else
                return item;
        }

        [HttpPost("", Name = "AddImage")]
        public async Task<ActionResult<ImageData>> AddImage()
        {
            StorageHelper.ConnectionString = configuration.GetValue<string>("StorageConnectionString");
            ImageData imageData = new ImageData();
            var file = Request.Form.Files[0];
            imageData.Caption = file.FileName;
            imageData.Description = file.FileName;
            imageData.ImageUrl = file.FileName;
            imageData.PosetedBy = "ashok@gmail.com";
            imageData.PostedDate = DateTime.Now;
            string filePath = $@"{Path.Combine(_hostingEnvironment.WebRootPath, "images")}\{Path.GetFileName(file.FileName)}";

            if (file.Length > 0)
            {
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }
                StorageHelper.UploadImage(filePath, "myfiles");
            }
            var result = await this.repository.AddAsync(imageData);
            return result;
        }

        [HttpPut("{id:int?}", Name = "UpdateImage")]
        public async Task<ActionResult<ImageData>> UpdateImage(int? id, ImageData imageData)
        {
            if (id == null) return BadRequest();
            if (id.Value == imageData.Id) return NotFound();
            var item = await this.repository.UpdateAsync(id.Value, imageData);
            return item;
        }

        [HttpDelete("{id:int?}", Name = "DeleteImage")]
        public async Task<ActionResult<ImageData>> DeleteImage(int? id)
        {
            if (id == null) return BadRequest();
            var result = await this.repository.DeleteAsync(id.Value);
            if (result == null)
                return NotFound();
            return result;
        }
    }
}