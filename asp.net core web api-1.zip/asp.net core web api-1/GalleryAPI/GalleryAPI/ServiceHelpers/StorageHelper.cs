﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace GalleryAPI.ServiceHelpers
{
    public class StorageHelper
    {
        private static string _connectionString;
        private static CloudStorageAccount storageAccount;

        public static string ConnectionString
        {
            get { return _connectionString; }
            set
            {
                if (_connectionString != value)
                {
                    _connectionString = value;
                    ConfigureStorage();
                }
            }
        }

        private static void ConfigureStorage()
        {
            if(!CloudStorageAccount.TryParse(_connectionString,out storageAccount))
            {
                throw new Exception("Could not initialize storage account object");
            }
        }

        public static async void UploadImage(string imagePath,string containerName)
        {
            var fileName = Path.GetFileName(imagePath);
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer cloudBlobContainer = blobClient.GetContainerReference(containerName);
           // await cloudBlobContainer.CreateAsync();
            //if (!containerCreated)
            //{
            //    throw new Exception("could not create the blob container");
            //}
            //BlobContainerPermissions permissions = new BlobContainerPermissions
            //{
            //    PublicAccess = BlobContainerPublicAccessType.Blob
            //};
            //await cloudBlobContainer.SetPermissionsAsync(permissions);
            CloudBlockBlob blob = cloudBlobContainer.GetBlockBlobReference(fileName);
            await blob.UploadFromFileAsync(imagePath);
        }
    }
}
