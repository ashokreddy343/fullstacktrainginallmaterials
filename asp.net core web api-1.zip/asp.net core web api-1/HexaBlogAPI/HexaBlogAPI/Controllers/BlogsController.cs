﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HexaBlogAPI.Models;
using HexaBlogAPI.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HexaBlogAPI.Controllers
{
    [EnableCors("MyPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class BlogsController : ControllerBase
    {
        private IRepository<Blog> repository;

        
        public BlogsController(IRepository<Blog> repo)
        {
            this.repository = repo;
        }

        //GET /api/blogs
        [ProducesResponseType(200)]
        [ProducesResponseType(typeof(IEnumerable<Blog>),200)]
        [HttpGet("",Name ="ListBlogs")]
        public IEnumerable<Blog> GetBlogs()
        {
            //throw new ArgumentException("Error");
             return this.repository.GetAll();
        }

        
        [ProducesResponseType(404)]
        [ProducesResponseType(200)]
        [HttpGet("{id:int}",Name ="GetBlog")]
        public async Task<ActionResult<Blog>> GetBlogById(int id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            var item = await this.repository.GetByIdAsync(id);
            if (item == null)
                return NotFound();
            else
                return item;
        }

        //POST /api/blogs
        /// <summary>
        /// Add a new blog to the blogs collection
        /// </summary>
        /// <remarks>
        /// POST /api/blog
        /// Sample data
        /// {
        /// "title":"Blog Title",
        /// "content":"Blog content",
        /// "addedBy":"Author email",
        /// "addedDate":"Posted Date"
        /// }
        /// </remarks>
        /// <param name="blog"></param>
        /// <returns>Newly inserted blog object</returns>
        /// <response code="201">New blog item is created</response>
        /// <response code="400">If Invalid blog input object</response>
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [HttpPost("",Name ="AddBlog") ]
        public async Task<ActionResult<Blog>> AddBlog(Blog blog)
        {
            if (blog == null)
            {
                return BadRequest();
            }
            var result = await this.repository.AddAsync(blog);
            //return result;
            //return CreatedAtAction("GetBlogById", result);
            return CreatedAtAction("GetBlogById", new {id=result.Id });
        }

        //PUT /api/blogs/{id}
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [ProducesResponseType(200)]
        [HttpPut("{id:int?}",Name ="UpdateBlog")]
        public async Task<ActionResult<Blog>> UpdateBlog(int? id ,Blog blog)
        {
            if (id == null) return BadRequest();
            if (id.Value != blog.Id) return NotFound();
            var item = await this.repository.UpdateAsync(id.Value, blog);
            return item;
        }

        //DELETE  /api/blogs/{id}
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [ProducesResponseType(200)]
        [HttpDelete("{id:int?}",Name ="DeleteBlog")]
        public async Task<ActionResult<Blog>> DeleteBlog(int? id)
        {
            if (id == null) return BadRequest();
            var result = await this.repository.DeleteAsync(id.Value);
            if (result == null)
                return NotFound();
            return result;
        }
    }
}