﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using HexMvcClient.Models;
using Microsoft.AspNetCore.Authorization;
using System.Net.Http;
using Newtonsoft.Json.Linq;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Configuration;

namespace HexMvcClient.Controllers
{
    public class HomeController : Controller
    {
        private string  blogUrl;

        public HomeController(IConfiguration config)
        {
            this.blogUrl = config.GetValue<string>("BlogApiUrl");
        }
        [Authorize]
        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> Blogs()
        {
            try
            {
                var accessToken = await HttpContext.GetTokenAsync("access_token");

                var client = new HttpClient();
                client.SetBearerToken(accessToken); //IdentityModel package
                var content = await client.GetStringAsync($"{this.blogUrl}/api/blogs");

                ViewBag.Json = JArray.Parse(content).ToString();
                return View();
            }catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                return View();
            }
        }
        
        public async void Logout()
        {
            await HttpContext.SignOutAsync("Cookies");
            await HttpContext.SignOutAsync("oidc");
        }

       

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
