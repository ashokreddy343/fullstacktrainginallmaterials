﻿using IdentityServer4;
using IdentityServer4.Test;
using IdentityServer4.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Security.Claims;

namespace IdentityServer
{
    public class Config
    {
        public static IEnumerable<ApiResource> GetApiResources()
        {
            return new List<ApiResource>
            {
                new ApiResource("BlogAPI","Blog API")
            };
        }

        public static IEnumerable<Client> GetClients(Dictionary<string, string> clientUrls)
        {
            return new List<Client>
            {
                new Client
                {
                    ClientId="mvc",
                    ClientName="MVC client",
                    AllowedGrantTypes=GrantTypes.HybridAndClientCredentials,
                    RequireConsent=true,
                    ClientSecrets =
                    {
                        new Secret("secret".Sha256())
                    },
                    //RedirectUris={ "http://localhost:7002/signin-oidc"},
                    RedirectUris={ $"{clientUrls["mvc"]}/signin-oidc"},
                    //PostLogoutRedirectUris={"http://localhost:7002/signout-callback-oidc"},
                    PostLogoutRedirectUris={$"{clientUrls["mvc"]}/signout-callback-oidc"},
                    AllowedScopes=new List<string>
                    {
                        IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.Profile,
                        "BlogAPI"
                    },
                    AllowOfflineAccess=true //to gain refresh token for long lived APIs
                },
                new Client
                {
                    ClientId="spa",
                    ClientName="SPA client",
                    AllowedGrantTypes=GrantTypes.Implicit, //implicit for javascript applications
                    AllowAccessTokensViaBrowser=true,

                    //RedirectUris={ "http://localhost:7003/callback.html"},
                    RedirectUris={ $"${clientUrls["spa"]}/callback.html"},
                    PostLogoutRedirectUris={ $"${clientUrls["spa"]}/index.html"},
                   // PostLogoutRedirectUris={"http://localhost:7003/index.html"},
                   AllowedCorsOrigins={ $"${clientUrls["spa"]}"},
                   // AllowedCorsOrigins={"http://localhost:7003"},

                    AllowedScopes=
                    {
                        IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.Profile,
                        "BlogAPI"
                    },
                    AllowOfflineAccess=true //to gain refresh token for long lived APIs
                }


            };
        }

        public static List<TestUser> GetUsers()
        {
            return new List<TestUser>
            {
                new TestUser
                {
                    SubjectId="1",
                    Username="ashok",
                    Password="password",
                    Claims = new[]
                    {
                        new Claim("name","ashok"),
                        new Claim("website","https://streamingskills.blog")
                    }
                },
                new TestUser
                {
                    SubjectId="2",
                    Username="bob",
                    Password="password",
                    Claims = new[]
                    {
                        new Claim("name","bob"),
                        new Claim("website","https://bob.blog")
                    }
                }
            };
        }

        public static IEnumerable<IdentityResource> GetIdentityResources()
        {
            return new List<IdentityResource>
            {
                new IdentityResources.OpenId(),
                new IdentityResources.Profile(),
            };
        }
    }
}
