﻿using Basket.API.Repositories;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using StackExchange.Redis;
using Swashbuckle.AspNetCore.Swagger;
using System;
using System.IO;
using System.Reflection;

namespace Basket.API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        /// <summary>
        /// This method gets called by the runtime. Use this method to add services to the container.
        /// </summary>
        /// <param name="services"></param>
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
            services.AddTransient<IBasketRepository, BasketRepository>();



            services.AddCors(options =>
            {
                options.AddPolicy("HexPolicy",
                    builder => builder.AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .AllowCredentials());
            });

            services.AddSingleton<ConnectionMultiplexer>(sp =>
            {

                var configuration = new ConfigurationOptions
                {
                   // EndPoints = { "localhost" }
                    EndPoints = { Configuration.GetValue<string>("RedisEndpoint") }
                };

                configuration.ResolveDns = true;

                return ConnectionMultiplexer.Connect(configuration);
            });


            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new Info
                {
                    Title = "Basket API",
                    Version = "v1",
                    Contact = new Contact
                    {
                        Name = "ashok reddy",
                        Email = "ashokreddyn@hexaware.com",
                        Url = "https://hexblog.azurewebsites.net"
                    },
                    Description = "basket added by hexaware",
                    TermsOfService = string.Empty,
                    License = new License { Name = "MIT License", Url = "https://hexblog.azurewebsites.net/license" }
                });
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                options.IncludeXmlComments(xmlPath);
            });
        }

        /// <summary>
        /// Configure middleware requests
        /// </summary>
        /// <param name="app"></param>
        /// <param name="env"></param>
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseStaticFiles();
            app.UseCors("HexPolicy");
            app.UseSwagger();
            app.UseSwaggerUI(options =>
            {
                options.SwaggerEndpoint("/swagger/v1/swagger.json", "HexaBlog API");
                options.RoutePrefix = string.Empty;
            });

            app.UseMvc();
        }
    }
}
