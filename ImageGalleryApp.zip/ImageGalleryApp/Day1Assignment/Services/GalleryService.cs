﻿using Day1Assignment.Models;
using Day1Assignment.ServiceHelpers;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Azure.Documents;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Day1Assignment.Services
{
    public class GalleryService : IGalleryService
    {
        private Dictionary<string, string> imageDict = new Dictionary<string, string>();

        public IEnumerable<ImageData> GetImages()
        {
            //var files= await StorageHelper.GetFilesAsync("images");
            //foreach(var file in files)
            //{
            //    imageDict.TryAdd(Path.GetFileName(file), file);
            //}
            return CosmosHelper.GetImageDocuments("gallerydb", "images");
            //return imageDict;
        }

        public async Task<ImageData> AddImageAsync(ImageData imageData, string imagePath)
        {
             var blobUrl = await StorageHelper.UploadImageAsync(imagePath, "images");
            //return blobUrl;

            //var containerSasUri = await StorageHelper.GetContainerSasUri("images", DateTimeOffset.UtcNow.AddDays(2));
            //var blobUrl = await StorageHelper.UploadImageWithContainerSasAsync(imagePath, containerSasUri);

            imageData.AddedDate = DateTime.Now;
            imageData.properties = new ImageProperties { ContentType = GetFileType(imagePath), SizeInBytes = GetFileSize(imagePath) };
            imageData.ImageUrl = blobUrl;

            return await CosmosHelper.CreateDocumentAsync("gallerydb", "images", imageData);
            //return blobUrl;
        }

        private string GetFileType(string filePath)
        {
            var provider = new FileExtensionContentTypeProvider();
            string contentType;
            if (!provider.TryGetContentType(filePath, out contentType))
            {
                contentType = "application/octet-stream";
            }
            return contentType;
        }

        private long GetFileSize(string filePath)
        {
            FileInfo info = new FileInfo(filePath);
            return info.Length;
        }
    }
}
