﻿using Day1Assignment.Models;
using Microsoft.Azure.Documents;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Day1Assignment.Services
{
    public interface IGalleryService
    {
        IEnumerable<ImageData> GetImages();
       Task<ImageData> AddImageAsync(ImageData imageData, string imagePath);
    }
}
