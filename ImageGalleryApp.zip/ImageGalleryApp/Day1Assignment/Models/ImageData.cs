﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Day1Assignment.Models
{
    public class ImageData
    {
        public string Caption { get; set; }

        public string Description { get; set; }
       
        public string ImageUrl { get; set; }

        public string AddedBy { get; set; }

        public DateTime AddedDate { get; set; }

        public ImageProperties properties { get; set; }
    }

    public class ImageProperties
    {
        public string ContentType { get; set; }
        public long SizeInBytes { get; set; }
    }
}
