﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Day1Assignment.Models;
using Day1Assignment.ServiceHelpers;
using Day1Assignment.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace Day1Assignment.Controllers
{
    public class GalleryController : Controller
    {
        private IGalleryService service;
        private IHostingEnvironment environment;
        private IConfiguration config;

        public GalleryController(IGalleryService svc, IHostingEnvironment environment, IConfiguration configuration)
        {
            this.service = svc;
            this.environment = environment;
            this.config = configuration;
            StorageHelper.ConnectionString = config.GetValue<string>("StorageConnectionString");
            CosmosHelper.EndPoint = configuration.GetValue<string>("Cosmos:EndpointUri");
            CosmosHelper.Key = configuration.GetValue<string>("Cosmos:Key");
        }

        
        public IActionResult Index()
        {
            IEnumerable<ImageData> model;
            try
            {
                model = service.GetImages();
            }
            catch(Exception ex)
            {
                model = Enumerable.Empty<ImageData>();
            }
            //ViewBag.Images = await service.GetImagesAsync();
            return View(model);
        }

        [HttpGet("addimage", Name ="addimage")]
        public IActionResult AddImage()
        {
            return View();
        }

        [HttpPost("addimage", Name ="addimage")]
        public async Task<IActionResult> AddImage(ImageData imageData, IFormFile file)
        {            
            var filePath = $@"{Path.Combine(environment.ContentRootPath, "images")}\{Path.GetFileName(file.FileName)}";
            if (file!=null && file.Length > 0)
            {
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);                    
                }
                await service.AddImageAsync(imageData, filePath);
                ViewBag.Message = "Image uploaded successfully";
            }
            else
            {
                ModelState.AddModelError("", "No images selected");
            }
            return View();
        }
    }
}