﻿using Day1Assignment.Models;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Day1Assignment.ServiceHelpers
{
    public static class CosmosHelper
    {
        #region Private members
        private static string _endpoint { get; set; }
        private static string _key { get; set; }
        private static DocumentClient client;
        #endregion

        #region Properties
        public static string EndPoint
        {
            get { return _endpoint; }
            set
            {
                if (_endpoint != value)
                {
                    _endpoint = value;
                }
                Initialize();
            }
        }
        public static string Key
        {
            get { return _key; }
            set
            {
                if (_key != value)
                {
                    _key = value;
                     Initialize();
                }
            }
        }
        #endregion

        #region private methods
        private static void Initialize()
        {
            if(!string.IsNullOrEmpty(_endpoint) && !string.IsNullOrEmpty(_key))
            {
                client = new DocumentClient(new Uri(_endpoint), _key);
            }
        }
        #endregion

        #region Public methods
        public static async Task<ImageData> CreateDocumentAsync(string databaseId,string collectionId,object document)
        {
            await client.CreateDatabaseIfNotExistsAsync(new Database { Id = databaseId });
            await client.CreateDocumentCollectionIfNotExistsAsync(UriFactory.CreateDatabaseUri(databaseId), new DocumentCollection { Id = collectionId });
            var result=await client.CreateDocumentAsync(UriFactory.CreateDocumentCollectionUri(databaseId, collectionId), document);
            if (result.StatusCode == HttpStatusCode.Created)
                return new ImageData
                {
                    Caption = result.Resource.GetPropertyValue<string>("Caption"),
                    Description = result.Resource.GetPropertyValue<string>("Description"),
                    ImageUrl = result.Resource.GetPropertyValue<string>("ImageUrl"),
                    AddedBy = result.Resource.GetPropertyValue<string>("AddedBy"),
                    AddedDate = result.Resource.GetPropertyValue<DateTime>("AddedDate"),
                    properties = result.Resource.GetPropertyValue<ImageProperties>("properties")
                };
            else
                throw new Exception("could not create document");
        }

        public static IEnumerable<ImageData> GetImageDocuments(string databaseId,string collectionId)
        {
            try
            {
                var collectuionUri = UriFactory.CreateDocumentCollectionUri(databaseId, collectionId);
                FeedOptions queryOptions = new FeedOptions { MaxItemCount = -1 };
                IQueryable<ImageData> imageQuery = client.CreateDocumentQuery<ImageData>(collectuionUri, queryOptions);
                return imageQuery.AsEnumerable();
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion

    }
}
